package com.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.exception.ProductNotFoundException;
import com.crud.model.Product;
import com.crud.repo.ProductRepository;

@Service
public class ProductServiceImp implements ProductService {

	@Autowired
	ProductRepository prepo;
	@Override
	public Product createProduct(Product p) {
		
		return prepo.save(p);
	}

	@Override
	public List<Product> getAllProduct() {
		
		return prepo.findAll();
	}

	@Override
	public Product getProductById(Long id) {
		Optional<Product>readP=prepo.findById(id);
		if(readP.isPresent()) {
			return readP.get();
		}
		else{
			throw new ProductNotFoundException("Searching product Id not available!!!");
		}
	}

	@Override
	public Product updateProduct(Product p) {
		Optional<Product>updatep=prepo.findById(p.getId());
		if(updatep.isPresent()) {
			Product product= updatep.get();
			product.setName(p.getName());
			product.setDescription(p.getDescription());
			product.setPrice(p.getPrice());
			prepo.save(product);
			return product;
		}
		else{
			throw new ProductNotFoundException("Searching product Id not available!!!");
		}
		
		
	}

	@Override
	public void deleteProductById(Long id) {
		Optional<Product>deleteid=prepo.findById(id);
		if(deleteid.isPresent()) {
			prepo.deleteById(id);
			
		}
		throw new ProductNotFoundException("Given product id not available");
		
	}

}
