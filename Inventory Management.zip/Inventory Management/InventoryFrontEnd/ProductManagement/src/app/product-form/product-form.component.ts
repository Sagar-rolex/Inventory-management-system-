import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductServiceService } from '../product-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-product-form',
  standalone: false,
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent implements OnInit {
  productForm: FormGroup;
  productId: number | null = null;
  constructor(private fb: FormBuilder, private productService: ProductServiceService, private route: ActivatedRoute, private router: Router) {
      this.productForm = this.fb.group({ name: ['', Validators.required], description: ['', Validators.required], price: [0, Validators.required] });
  }
  ngOnInit(): void {
      this.route.params.subscribe(params => {
          this.productId = params['id'];
          if (this.productId) {
              this.productService.getProduct(this.productId).subscribe(product => this.productForm.patchValue(product));
          }
      });
  }
  onSubmit(): void {
      if (this.productForm.valid) {
          if (this.productId) {
              this.productService.updateProduct(this.productId, this.productForm.value).subscribe(() => this.router.navigate(['/products']));
          } else {
              this.productService.createProduct(this.productForm.value).subscribe(() => this.router.navigate(['/products']));
          }
      }
  }
}
