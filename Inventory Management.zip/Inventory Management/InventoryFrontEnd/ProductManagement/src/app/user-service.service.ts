import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private apiUrl = 'http://localhost:9092/api/users';
    constructor(private http: HttpClient) {}
    registerUser(user: User): Observable<User> { 
      return this.http.post<User>(`${this.apiUrl}/register`, user); 
    }
    loginUser(user: User): Observable<User> { 
      return this.http.post<User>(`${this.apiUrl}/login`, user); }
}

