import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  registerForm: FormGroup;
  constructor(private fb: FormBuilder, private userService: UserServiceService, private router: Router) {
      this.registerForm = this.fb.group({ username: ['', Validators.required], password: ['', Validators.required] });
  }
  onSubmit(): void {
      if (this.registerForm.valid) {
          this.userService.registerUser(this.registerForm.value).subscribe(() => this.router.navigate(['/login']));
      }
  }
}
