import { Component } from '@angular/core';
import { Product } from '../product';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  products: Product[] = [];
  constructor(private productService: ProductServiceService) {}
  ngOnInit(): void { this.loadProducts(); }
  loadProducts(): void { this.productService.getProducts().subscribe(products => this.products = products); }
  deleteProduct(id: number): void { this.productService.deleteProduct(id).subscribe(() => this.loadProducts()); }
}
