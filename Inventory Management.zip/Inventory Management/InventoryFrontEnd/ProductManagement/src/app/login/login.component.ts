import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  constructor(private fb: FormBuilder, private userService: UserServiceService, private router: Router) {
      this.loginForm = this.fb.group({ username: ['', Validators.required], password: ['', Validators.required] });
  }
  onSubmit(): void {
      if (this.loginForm.valid) {
          this.userService.loginUser(this.loginForm.value).subscribe(user => {
              if (user) { this.router.navigate(['/products']); } else { alert('Invalid credentials'); }
          });
      }
  }
}
